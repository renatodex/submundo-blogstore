<?php

/*
Plugin Name: Portfolio Postype
Plugin URI: http://weekend.id
Description: Portfolio Postype
Author: Weekend
Author URI: http://weekend.id
Version: 1.0
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit();

/* ------------------------------------------------------------------------ */
/* The Portfolio class
/* ------------------------------------------------------------------------ */

class Wi_Portfolio {

	/* ------------------------------------------------------------------------ */
	/* The constructor method for the Portfolio class
	/* ------------------------------------------------------------------------ */

	function __construct() {
		add_action( 'init', array( &$this, 'portfolio_init' ) );
		add_filter( 'manage_edit-portfolio_columns', array( &$this, 'add_thumbnail_column'), 10, 1 );
		add_action( 'manage_posts_custom_column', array( &$this, 'display_thumbnail' ), 10, 1 );
		add_action( 'restrict_manage_posts', array( &$this, 'add_taxonomy_filters' ) );
	}

	/* ------------------------------------------------------------------------ */
	/* Register Portfolio post type
	/* ------------------------------------------------------------------------ */

	function portfolio_init() {

		// Register the post type
		$labels = array(
			'name'					=> 'Portfolio',
			'singular_name'			=> 'Portfolio',
			'all_items'				=> 'All Portfolio',
			'add_new'				=> 'Add New',
			'add_new_item'			=> 'Add New Portfolio',
			'edit_item'				=> 'Edit Portfolio',
			'new_item'				=> 'New Portfolio',
			'view_item'				=> 'View Portfolio',
			'search_items'			=> 'Search Portfolio',
			'not_found'				=> 'No Portfolio found',
			'not_found_in_trash'	=> 'No Portfolio found in Trash'
		);

		$args = array(
			'labels'				=> $labels,
			'public'				=> true,
			'exclude_from_search'	=> true,
			'publicly_queryable'	=> true,
			'show_ui'				=> true, 
			'query_var'				=> true,
			'capability_type'		=> 'post',
			'hierarchical'			=> false,
			'menu_position' 		=> null,
			'rewrite'				=> array( 'slug' => 'portfolio' ),
			'supports'				=> array( 'title', 'editor', 'thumbnail' )
		);
		register_post_type( 'portfolio', $args );

		// Register portfolio categories
		$portfolio_category_labels = array(
			'name'					=> 'Portfolio Categories',
			'singular_name'			=> 'Category',
			'search_items'			=> 'Search Categories',
			'all_items'				=> 'All Categories',
			'parent_item'			=> 'Parent Category',
			'parent_item_colon'		=> 'Parent Category:',
			'edit_item'				=> 'Edit Category',
			'update_item'			=> 'Update Category',
			'add_new_item'			=> 'Add New Category',
			'new_item_name'			=> 'New Category Name',
			'menu_name'				=> 'Categories',
		);

		$portfolio_category_args = array(
			'labels'				=> $portfolio_category_labels,
			'public' 				=> true,
			'show_in_nav_menus'		=> true,
			'show_ui'				=> true,
			'show_admin_column'		=> true,
			'show_tagcloud'			=> false,
			'query_var'				=> true,
			'hierarchical'			=> true,
			'rewrite'				=> array( 'slug' => 'portfolio-category' ),
		);
		register_taxonomy( 'portfolio-category', 
			array( 'portfolio' ), 
			$portfolio_category_args 
		);
	}

	/* ------------------------------------------------------------------------ */
	/* Add thumbnail column
	/* ------------------------------------------------------------------------ */

	function add_thumbnail_column( $columns ) {
		$column_thumb = array( 'thumbnail' => 'Thumbnail' );
		$columns = array_slice( $columns, 0, 2, true ) + $column_thumb + array_slice( $columns, 1, NULL, true );
		return $columns;
	}

	/* ------------------------------------------------------------------------ */
	/* Display thumbnail
	/* ------------------------------------------------------------------------ */

	function display_thumbnail( $column ) {
		global $post;
		switch ( $column ) {
			case 'thumbnail' :
				echo get_the_post_thumbnail( $post->ID, array( 35, 35 ) );
				break;
		}
	}

	/* ------------------------------------------------------------------------ */
	/* Add taxonomy filter to the admin page
	/* ------------------------------------------------------------------------ */

	function add_taxonomy_filters() {
		global $typenow;
		$taxonomies = array( 'portfolio-category' );

		if ( $typenow == 'portfolio' ) {
			foreach ( $taxonomies as $tax_slug ) {
				$current_tax_slug = isset( $_GET[$tax_slug] ) ? $_GET[$tax_slug] : false;
				$tax_obj = get_taxonomy( $tax_slug );
				$terms = get_terms( $tax_slug );
				if ( count( $terms ) > 0) {
					echo '<select name="' . $tax_slug . '">';
					echo '<option value="">View all categories</option>';
					foreach ( $terms as $term ) {
						echo '<option value=' . $term->slug, $current_tax_slug == $term->slug ? ' selected="selected"' : '','>' . $term->name . ' (' . $term->count . ')</option>';
					}
					echo '</select>';
				}
			}
		}
	}

}
new wi_portfolio();